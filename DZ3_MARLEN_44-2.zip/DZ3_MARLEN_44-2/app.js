    let amountNumbers = [5,8,1,15,47,26,52,14,16,39];

    let evenNumbers = 0;
    let notEvenNumbers = 0;
    for (let i = 0; i < amountNumbers.length; i++) {
        if (amountNumbers[i] % 2 === 0){
            evenNumbers += amountNumbers [i];
        } else {
            notEvenNumbers += amountNumbers[i];
        }
    }

    console .log('Четных чисел', evenNumbers, 'Нечетных чисел', notEvenNumbers,);


    let Grades = [5, 4, 5, 3, 2, 1, 3]
    for (let i = 0; i <Grades.length; i++) {
        let gradeLetter;
        switch (Grades[i]) {
            case 5:
                gradeLetter = 'A';
                break;
            case 4:
                gradeLetter = 'B';
                break;
            case 3:
                gradeLetter = 'C';
                break;
            case 2:
                gradeLetter = 'D';
                break;
            case 1:
                gradeLetter = 'E';
                break;
            default:
                console.error('Invalid grade')
        }
        console.log ( gradeLetter, ' ', Grades[i]);
    }

